# Learning annotations: original executable code is preserved.
# torchrun supplies worker identity through environment variables. PBS will
# allocate resources; the cluster-specific launcher must start torchrun.

import os

# Return (distributed, global rank, node-local rank, total worker count).
# Global rank identifies a worker across the entire job. Local rank selects
# a GPU within that node's visible devices. World size counts all workers.
def get_distributed_info():
    # Presence, not WORLD_SIZE > 1, selects distributed mode. Thus even a
    # one-worker torchrun launch enters this project's CUDA/NCCL path.
    # TODO: validate LOCAL_RANK too, plus integer values and valid ranges.
    # A partial launcher environment currently raises an error below.
    distributed = "RANK" in os.environ and "WORLD_SIZE" in os.environ

    if distributed:
        rank = int(os.environ["RANK"])
        # This value is read from the environment, not args.local_rank.
        # Example: two nodes with two GPUs each have global ranks 0..3,
        # but local ranks 0 and 1 repeat on each node.
        local_rank = int(os.environ["LOCAL_RANK"])
        world_size = int(os.environ["WORLD_SIZE"])
    # Plain python execution normally has none of these launcher variables.
    # Defaults let rank-0-only work also run in the single-device case.
    else:
        rank = 0
        local_rank = 0
        world_size = 1

    return distributed, rank, local_rank, world_size