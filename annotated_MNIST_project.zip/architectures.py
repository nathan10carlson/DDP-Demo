# Learning annotations: original executable code is preserved.
# CNN2D owns tensor computation; launching and training live in MNIST_demo.py.

import torch
import torch.nn as nn

# nn.Module registers child layers so parameters(), .to(), and train()/eval()
# can operate on the whole model. This model class is the same under DDP.
class CNN2D(nn.Module):
    def __init__(self):
        super().__init__()

        # Input: [B, 1, 28, 28], where B is the current batch size.
        # A 3x3 kernel with padding 1 and default stride 1 preserves 28x28.
        # Output: [B, 16, 28, 28]; channels are features, not digit classes.
        self.first_CNN_layer = nn.Conv2d(
            in_channels=1,
            out_channels=16,
            kernel_size=3,
            padding=1
        )
        # ReLU clips negative activations to zero. This stateless module can
        # be reused at several points in forward().
        self.ReLU = nn.ReLU()
        # Convert 16 feature channels into 32: [B, 32, 28, 28].
        # There is no pooling in this network, so spatial size stays unchanged.
        self.second_CNN_layer = nn.Conv2d(
            in_channels=16,
            out_channels=32,
            kernel_size=3,
            padding=1
        )
        # LazyLinear infers its input width on the first forward pass:
        # 32 * 28 * 28 = 25,088 features per image, mapped to 128 features.
        # The dummy forward in MNIST_demo.py initializes this before DDP.
        # After initialization, a different image size needs reconsideration.
        self.dense_1 = nn.LazyLinear(128)
        # there are 10 classes
        # [B, 128] -> [B, 10]: one unnormalized score (logit) per digit.
        self.dense_2 = nn.Linear(128,10)

    # Calling model(images) invokes this method through nn.Module.
    # Keep the batch axis separate throughout the computation.
    def forward(self, x):
        x = self.first_CNN_layer(x)
        x = self.ReLU(x)
        x = self.second_CNN_layer(x)
        x = self.ReLU(x)
        # Flatten from dimension 1, retaining B: [B, 32, 28, 28]
        # becomes [B, 25088]. Flattening dimension 0 would mix examples.
        x = torch.flatten(x,1)
    
        x = self.dense_1(x)
        x = self.ReLU(x)
        x = self.dense_2(x)
        # this returns logits
        # Do not add softmax here: CrossEntropyLoss expects logits.
        # argmax(logits, dim=1) chooses a digit without needing softmax.
        return x