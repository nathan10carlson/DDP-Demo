# Learning annotations: all original executable statements are preserved.
# Read in order: arguments -> worker identity -> device -> model -> data ->
# loaders -> training -> rank-0 evaluation/plotting -> distributed cleanup.
#
# TODO comments describe improvements; they are NOT implemented here.
# Before multi-rank use: bind CUDA explicitly, coordinate dataset preparation,
# and make plotting/output paths safe. PBS launch syntax remains site-specific.
# A job array runs independent configurations; DDP workers cooperate on ONE
# configuration. Every rank in that DDP job should use matching settings.
#
# Single-device example using the existing parser:
#   python MNIST_demo.py --learning-rate 0.001 --epochs 2 --batch-size 64
# After addressing the multi-rank TODOs, a two-visible-CUDA-GPU node can use:
#   torchrun --standalone --nnodes=1 --nproc-per-node=2 MNIST_demo.py
# This allocates no HPC resources and is not a PBS submission command.
#
# TODO: put execution in main() with an if __name__ == "__main__" guard
# before importing this script or adding spawned DataLoader worker processes.

import torch

import torch.nn as nn
import matplotlib.pyplot as plt
import argparse

from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import torch.distributed as dist
from torch.utils.data.distributed import DistributedSampler
from torch.nn.parallel import DistributedDataParallel as DDP

from architectures import CNN2D
from utils import get_distributed_info

# Command-line hyperparameters let batch jobs reuse one script unchanged.
# A separate Cartesian-product sweep can select (lr, batch_size, epochs)
# tuples, each with a fresh process/model/optimizer. No sweep exists here.
# TODO: add seed, data directory, output directory, and run ID arguments.
# Record settings and use distinct outputs for each independent experiment.
parser = argparse.ArgumentParser()

parser.add_argument(
    "--learning-rate",
    type=float,
    default=0.001
)

parser.add_argument(
    "--epochs",
    type=int,
    default=10
)

parser.add_argument(
    "--batch-size",
    type=int,
    default=64
)

parser.add_argument(
    "--local-rank",
    "--local_rank",
    type=int,
    default=0
)

# argparse converts --learning-rate to args.learning_rate and parses types.
# TODO: validate positive ranges; type=int alone permits zero and negatives.
# The two local-rank argument spellings are accepted for compatibility, but
# get_distributed_info() below reads LOCAL_RANK, not args.local_rank.
args = parser.parse_args()

# rank: global worker ID; local_rank: worker/GPU index within this node;
# world_size: total workers. The ordinary single-device defaults are 0, 0, 1.
distributed, rank, local_rank, world_size = get_distributed_info()

# This initializes communication among workers that already exist. It does
# not spawn them. env:// uses the launcher's rendezvous environment.
# NCCL is the GPU backend for this project's CUDA distributed branch.
# TODO: validate CUDA availability and call torch.cuda.set_device(local_rank)
# BEFORE this initialization. Explicit .to(cuda:local_rank) below is not a
# replacement for setting the process's current CUDA device.
if distributed:
    dist.init_process_group(
    backend="nccl",
    init_method="env://"
    ) # this connects them

# Startup prints intentionally remain on every rank in this original code.
# Add rank labels or gate routine output if interleaved logs become confusing.
print(f"Distributed: {distributed}")
print(f"Rank: {rank}")
print(f"Local rank: {local_rank}")
print(f"World size: {world_size}")

learning_rate = args.learning_rate
num_epochs = args.epochs
batch_size = args.batch_size

# ============================================================
# DEVICE
# ============================================================
# Each DDP process owns one visible GPU. Local rank is not global rank:
# rank 2 on a second node might use that node's cuda:0. Scheduler GPU masking
# can also make visible indices differ from physical GPU labels.
# The non-distributed fallback supports CUDA, MPS, and CPU. The distributed
# branch does not: it explicitly requires CUDA/NCCL.
if distributed:
    device = torch.device(f"cuda:{local_rank}")
else:
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")

print(f"Using device: {device}")


# ============================================================
# MODEL
# ============================================================



# Each process creates a complete model replica. DDP is data parallelism,
# not model sharding; the model and optimizer must fit on each assigned GPU.
model = CNN2D().to(device)

# Quick sanity check
# [B, C, H, W] = [1, 1, 28, 28] should produce logits [1, 10].
# This first forward materializes LazyLinear's 25,088 input features.
# It must happen before wrapping uninitialized parameters in DDP.
# TODO: use torch.no_grad() for this sanity pass to avoid retaining its graph.
# No backward/optimizer step means this forward does not train the model.
dummy_data = torch.rand(1, 1, 28, 28).to(device)
dummy_output = model(dummy_data)
# this also sets the lazy linear layer
print(f"Dummy input shape:  {dummy_data.shape}")
print(f"Dummy output shape: {dummy_output.shape}")

# DDP coordinates replicas and installs gradient synchronization hooks.
# device_ids names the single visible GPU owned by this worker.
# It does NOT shard input data; the sampler below handles that.
if distributed:
    model = DDP(
        model,
        device_ids=[local_rank]
    )




# ============================================================
# DATASET
# ============================================================

# MNIST images become float tensors [1, 28, 28], normally in [0, 1].
# Labels are digit class indices 0..9. No extra normalization is used here.
transform = transforms.ToTensor()

# TODO: both download=True calls currently run on EVERY rank. Prepare the
# data once before launching, or let rank 0 prepare it on SHARED storage,
# let ALL ranks reach a barrier, then reopen with download=False.
# For node-local storage, prepare data on each node; global rank 0 cannot
# populate another node's private files. ./data is relative to the job cwd.
mnist_trainset = datasets.MNIST(
    root="./data",
    train=True,
    download=True,
    transform=transform
)

mnist_testset = datasets.MNIST(
    root="./data",
    train=False,
    download=True,
    transform=transform
)

print(f"Training samples: {len(mnist_trainset)}")
print(f"Testing samples:  {len(mnist_testset)}")


# ============================================================
# DATALOADERS
# ============================================================

# Each worker sees its own subset of training indices. All ranks must use
# the same underlying dataset ordering and compatible sampler settings.
# Default drop_last=False pads indices when needed, so a few examples can
# repeat when dataset size is not divisible by world_size.
if distributed:
    train_sampler = DistributedSampler(
        mnist_trainset,
        num_replicas=world_size,
        rank=rank,
        shuffle=True
    )
else:
    train_sampler = None

# batch_size is PER RANK, not global. Four workers with batch_size=64
# process 256 examples per full optimizer step (no accumulation here).
# The sampler owns shuffling under DDP; otherwise the loader shuffles.
# Default num_workers=0 loads in this process. Default drop_last=False
# keeps a final short batch; this is separate from sampler padding.
train_loader = DataLoader(
    mnist_trainset,
    batch_size=batch_size,
    shuffle=(train_sampler is None), # sampler handles shuffling in distrib mode
    sampler=train_sampler # 
) 

# This loader is deliberately unsharded: only global rank 0 evaluates it,
# covering the entire test set once. If evaluation is later distributed,
# partition examples and reduce counts without double-counting padding.
test_loader = DataLoader(
    mnist_testset,
    batch_size=batch_size,
    shuffle=False
)

# Inspect one batch
# Shapes: images [B, 1, 28, 28], labels [B]. This diagnostic uses a separate
# iterator; the later training loop starts a fresh iterator over the loader.
images, labels = next(iter(train_loader))

print(f"Batch image shape: {images.shape}")
print(f"Batch label shape: {labels.shape}")


# ============================================================
# TRAINING SETUP
# ============================================================

# Contract: logits [B, 10], integer class targets [B]. CrossEntropyLoss
# internally uses log-softmax; do not softmax the model output beforehand.
# Default reduction returns the mean loss for the current local batch.
criterion = nn.CrossEntropyLoss()

# Every rank owns an optimizer over its replica's initialized parameters.
# DDP synchronizes gradients; each optimizer applies the matching update.
optimizer = torch.optim.Adam(
    model.parameters(),
    lr=learning_rate
)


# ============================================================
# TRAINING
# ============================================================

# Training mode matters for layers such as dropout/batch normalization.
# The current CNN has neither, but preserving this step supports new models.
model.train()

for epoch in range(num_epochs):

    if distributed:
        # Change the shared shuffle seed each epoch while preserving rank
        # partitioning. Call before iterating; otherwise ordering repeats.
        train_sampler.set_epoch(epoch)

    epoch_loss = 0.0

    for images, labels in train_loader:

        # Move the current batch to the same device as the model
        images = images.to(device)
        labels = labels.to(device)

        # Forward pass
        logits = model(images)

        # Compare predictions against true labels
        loss = criterion(logits, labels)

        # Remove gradients left over from the previous batch
        optimizer.zero_grad()

        # Compute gradients
        # Autograd computes local derivatives. Under DDP, hooks mark gradient
        # buckets ready and launch all-reduce as backward progresses. Bucket
        # communication can overlap computation for earlier layers. Standard
        # DDP averages gradients across workers; it does not reduce loss.item().
        # All workers must execute compatible collective operations in order.
        loss.backward()

        # Update model parameters
        # Each rank updates locally from synchronized gradients. Matching
        # starting weights, gradients, and optimizer settings keep replicas
        # aligned; no rank-0-only optimizer step is needed or appropriate.
        optimizer.step()

        # loss.item() gives us the loss as a normal Python number
        epoch_loss += loss.item()

    # This is a LOCAL average of batch means, not a global dataset mean.
    # A partial final batch is weighted equally with a full one.
    # TODO: accumulate loss.item() * batch_count plus sample counts, reduce
    # their sums on ALL ranks, then print the ratio only on rank 0.
    # That statistic includes any samples repeated by sampler padding.
    average_loss = epoch_loss / len(train_loader)
    if rank == 0:
        print(
            f"Epoch {epoch + 1}/{num_epochs} "
            f"- Loss: {average_loss:.4f}"
        )

# All workers reach this meeting point before rank 0 begins evaluation.
# Never put this barrier inside a rank-0-only branch: peers must join it.
# A barrier is synchronization, not recovery from a failed worker.
if distributed:
    dist.barrier()
if rank == 0:
    print("Model trained.")


# ============================================================
# EVALUATION
# ============================================================

if rank == 0:
    print("\nEvaluating model...")

    # Unwrap DDP for this rank-only forward: peers are not participating in
    # wrapper-level communication. Safe for this CNN; a future model with
    # its own collectives needs a compatible evaluation plan on all ranks.
    eval_model = model.module if distributed else model
    # eval() changes layer behavior; no_grad() below disables gradient
    # recording. They serve distinct purposes. Resume train() if training
    # is later moved to continue after an evaluation phase.
    eval_model.eval()

    total = 0
    correct_guesses = 0

    all_incorrect_images = []
    all_incorrect_true = []
    all_incorrect_pred = []

    with torch.no_grad():

        for images, labels in test_loader:

            images = images.to(device)
            labels = labels.to(device)

            # Forward pass
            logits = eval_model(images)

            # Pick the class with the largest logit
            predictions = torch.argmax(logits, dim=1)

            # Determine which predictions were correct
            correct = predictions == labels

            correct_guesses += correct.sum().item()
            total += labels.shape[0]

            # Save incorrect predictions for visualization
            incorrect_mask = ~correct

            all_incorrect_images.append(
                images[incorrect_mask].cpu()
            )

            all_incorrect_true.append(
                labels[incorrect_mask].cpu()
            )

            all_incorrect_pred.append(
                predictions[incorrect_mask].cpu()
            )


    # Count examples, not batch accuracies, so a short batch is weighted
    # correctly. This is full-test accuracy because rank 0 sees all examples.
    # Use a validation split for tuning; reserve the test set for final checks.
    accuracy = correct_guesses / total

    print(f"Total samples:   {total}")
    print(f"Correct guesses: {correct_guesses}")
    print(f"Total accuracy:  {accuracy:.4f}")


    # ============================================================
    # COLLECT INCORRECT PREDICTIONS
    # ============================================================

    # The per-batch tensors were moved to CPU for plotting. Concatenation
    # joins examples along axis 0. For larger tasks, retain a bounded sample
    # of mistakes instead of storing every incorrect prediction.
    all_incorrect_images = torch.cat(all_incorrect_images)
    all_incorrect_true = torch.cat(all_incorrect_true)
    all_incorrect_pred = torch.cat(all_incorrect_pred)

    print(f"Incorrect predictions: {len(all_incorrect_images)}")


    # ============================================================
    # VISUALIZE 9 INCORRECT PREDICTIONS
    # ============================================================

    fig, axes = plt.subplots(3, 3, figsize=(8, 8))

    # TODO: this assumes at least nine mistakes. Hide unused axes and draw
    # only min(9, len(all_incorrect_images)); handle zero mistakes explicitly.
    # An IndexError here can leave peer ranks waiting at the final barrier.
    for i, ax in enumerate(axes.flat):

        image = all_incorrect_images[i].squeeze(0)

        true_label = all_incorrect_true[i].item()
        predicted_label = all_incorrect_pred[i].item()

        ax.imshow(image, cmap="gray")
        ax.set_title(
            f"True: {true_label} | Pred: {predicted_label}"
        )
        ax.axis("off")

    plt.tight_layout()
    # TODO: choose a unique run output directory; this filename is otherwise
    # overwritten by repeated or simultaneous jobs in the same directory.
    # Use a noninteractive Matplotlib backend for unattended HPC execution.
    plt.savefig("incorrect.png")
    plt.close()
    print("Saved incorrect predictions to incorrect.png")

# Nonzero ranks wait here while rank 0 evaluates and plots. All ranks must
# eventually reach this final barrier before cleanup. A rank-0 exception or
# evaluation longer than the communication timeout can fail the whole job.
# For PBS, first inspect PBS_NODEFILE, PBS_* variables, and qstat -f JOBID
# inside a real allocation. Nodefile repetitions need not count GPUs.
# Tailor remote launching, node ranks, storage, and rendezvous to the site.
if distributed:
    dist.barrier()
    dist.destroy_process_group()


